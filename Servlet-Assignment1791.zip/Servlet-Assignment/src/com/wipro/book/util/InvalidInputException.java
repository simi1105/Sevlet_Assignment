package com.wipro.book.util;

public class InvalidInputException extends Exception{
	public String toString(){
		return "Invalid Input";
	}
}
